package curso_programacao;

import java.util.Scanner;

public class repetitiva {

	public static void main(String[] args) {
	  
		Scanner sc = new Scanner(System.in);
		
		int x = sc.nextInt();
		while (x != 0) {

	}
		
		sc.close();
		
	}
}
