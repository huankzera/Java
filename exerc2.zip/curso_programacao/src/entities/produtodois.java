package entities;

public class produtodois {


		
	public String name;
	public double prince;
	public int quantity;
	
	
	public double totalValueInStock() {
		return prince * quantity;
				
	}

	public void addProducts(int quantity) {
		this.quantity += quantity;
	}
	
	public void removeProducts (int quantity) {
		this.quantity -= quantity;
	
	
	}

}