package application;

import boardgame.Position;

public class Program {

	public static void main(String[] args) {
		
		Position pos = new Position(3, 5);
		System.out.println(pos);
	}

}
