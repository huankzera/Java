package Exerciciossss;


	import java.util.Scanner;

	class Aluno {
	    private String ra;
	    private String nome;
	    private float ac1;
	    private float ac2;
	    private float ag;
	    private float af;

	    
	    public Aluno() {
	        ra = "";
	        nome = "";
	        ac1 = 0;
	        ac2 = 0;
	        ag = 0;
	        af = 0;
	    }

	    public void setRA(String ra) {
	        this.ra = ra;
	    }

	    public String getRA() {
	        return ra;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setAC1(float ac1) {
	        this.ac1 = ac1;
	    }

	    public float getAC1() {
	        return ac1;
	    }

	    public void setAC2(float ac2) {
	        this.ac2 = ac2;
	    }

	    public float getAC2() {
	        return ac2;
	    }

	    public void setAG(float ag) {
	        this.ag = ag;
	    }

	    public float getAG() {
	        return ag;
	    }

	    public void setAF(float af) {
	        this.af = af;
	    }

	    public float getAF() {
	        return af;
	    }

	    public float calcularMedia() {
	        return (ac1 * 0.15f) + (ac2 * 0.30f) + (ag * 0.10f) + (af * 0.45f);
	    }

	    public String verificarAprovacao() {
	        if (calcularMedia() >= 5) {
	            return "Aprovado";
	        } else {
	            return "Reprovado";
	        }
	    }

	    public String imprimir() {
	        return "RA: " + ra +
	               "\nNome: " + nome +
	               "\nAC1: " + ac1 +
	               "\nAC2: " + ac2 +
	               "\nAG: " + ag +
	               "\nAF: " + af +
	               "\nMédia: " + calcularMedia() +
	               "\nSituação: " + verificarAprovacao();
	    }
	}

	public class Exercicios2 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Aluno aluno = new Aluno();

	        int opcao;
	        do {
	            System.out.println("\nMenu:");
	            System.out.println("1 - Criar Aluno");
	            System.out.println("2 - Mostrar Aluno");
	            System.out.println("3 - Sair");
	            System.out.print("Escolha uma opção: ");
	            opcao = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (opcao) {
	                case 1:
	                    System.out.print("RA: ");
	                    aluno.setRA(scanner.nextLine());
	                    System.out.print("Nome: ");
	                    aluno.setNome(scanner.nextLine());
	                    System.out.print("AC1: ");
	                    aluno.setAC1(scanner.nextFloat());
	                    System.out.print("AC2: ");
	                    aluno.setAC2(scanner.nextFloat());
	                    System.out.print("AG: ");
	                    aluno.setAG(scanner.nextFloat());
	                    System.out.print("AF: ");
	                    aluno.setAF(scanner.nextFloat());
	                    break;
	                case 2:
	                    System.out.println(aluno.imprimir());
	                    break;
	                case 3:
	                    System.out.println("Saindo...");
	                    break;
	                default:
	                    System.out.println("Opção inválida.");
	            }
	        } while (opcao != 3);

	        scanner.close();
	    }
	}


