package Exerciciossss;


	import java.util.Scanner;

	class Funcionario {
	    private int cracha;
	    private String nome;
	    private char tipoVinculo;
	    private float valorHora;
	    private float qtdeHora;
	    private float salario;
	    private float valorDesconto;

	    public int getCracha() {
	        return cracha;
	    }

	    public void setCracha(int cracha) {
	        this.cracha = cracha;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }

	    public char getTipoVinculo() {
	        return tipoVinculo;
	    }

	    public void setTipoVinculo(char tipoVinculo) {
	        this.tipoVinculo = tipoVinculo;
	    }

	    public float getValorHora() {
	        return valorHora;
	    }

	    public void setValorHora(float valorHora) {
	        this.valorHora = valorHora;
	    }

	    public float getQtdeHora() {
	        return qtdeHora;
	    }

	    public void setQtdeHora(float qtdeHora) {
	        this.qtdeHora = qtdeHora;
	    }

	    public float getSalario() {
	        return salario;
	    }

	    public void setSalario(float salario) {
	        this.salario = salario;
	    }

	    public float getValorDesconto() {
	        return valorDesconto;
	    }

	    public void setValorDesconto(float valorDesconto) {
	        this.valorDesconto = valorDesconto;
	    }

	    public float calcularSalario() {
	        if (tipoVinculo == 'H') {
	            return valorHora * qtdeHora;
	        } else {
	            return salario;
	        }
	    }

	    public float calcularValorReceber() {
	        return salario - valorDesconto;
	    }

	    public String imprimir() {
	        return "Crachá: " + cracha +
	               "\nNome: " + nome +
	               "\nTipo Vínculo: " + tipoVinculo +
	               "\nSalário: " + salario +
	               "\nDesconto: " + valorDesconto +
	               "\nValor a receber: " + calcularValorReceber();
	    }
	}

	public class Exerciciosss3 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Funcionario funcionario = null;

	        int choice;
	        do {
	            System.out.println("\nMenu");
	            System.out.println("1 - Criar Funcionário");
	            System.out.println("2 - Mostrar Folha de Pagamento");
	            System.out.println("3 - Alterar Remuneração");
	            System.out.println("4 - Sair");
	            System.out.print("Escolha uma opção: ");
	            choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                    funcionario = criarFuncionario(scanner);
	                    break;
	                case 2:
	                    if (funcionario != null) {
	                        System.out.println(funcionario.imprimir());
	                    } else {
	                        System.out.println("Funcionário não foi criado ainda.");
	                    }
	                    break;
	                case 3:
	                    if (funcionario != null) {
	                        alterarRemuneracao(funcionario, scanner);
	                    } else {
	                        System.out.println("Funcionário não foi criado ainda.");
	                    }
	                    break;
	                case 4:
	                    System.out.println("Saindo do programa.");
	                    break;
	                default:
	                    System.out.println("Opção inválida. Escolha novamente.");
	            }
	        } while (choice != 4);
	    }

	    public static Funcionario criarFuncionario(Scanner scanner) {
	        Funcionario funcionario = new Funcionario();
	        System.out.print("Digite o crachá do funcionário: ");
	        funcionario.setCracha(scanner.nextInt());
	        scanner.nextLine(); 
	        System.out.print("Digite o nome do funcionário: ");
	        funcionario.setNome(scanner.nextLine());
	        System.out.print("Digite o tipo de vínculo (H para horista, N para normal): ");
	        funcionario.setTipoVinculo(scanner.nextLine().charAt(0));
	        
	        if (funcionario.getTipoVinculo() == 'H') {
	            System.out.print("Digite o valor da hora: ");
	            funcionario.setValorHora(scanner.nextFloat());
	            System.out.print("Digite a quantidade de horas trabalhadas: ");
	            funcionario.setQtdeHora(scanner.nextFloat());
	        } else {
	            System.out.print("Digite o salário: ");
	            funcionario.setSalario(scanner.nextFloat());
	        }
	        
	        System.out.print("Digite o valor do desconto: ");
	        funcionario.setValorDesconto(scanner.nextFloat());

	        return funcionario;
	    }

	    public static void alterarRemuneracao(Funcionario funcionario, Scanner scanner) {
	        if (funcionario.getTipoVinculo() == 'H') {
	            System.out.print("Digite o novo valor da hora: ");
	            funcionario.setValorHora(scanner.nextFloat());
	            System.out.print("Digite a nova quantidade de horas trabalhadas: ");
	            funcionario.setQtdeHora(scanner.nextFloat());
	        } else {
	            System.out.print("Digite o novo salário: ");
	            funcionario.setSalario(scanner.nextFloat());
	        }

	        System.out.println("Remuneração alterada com sucesso.");
	    }
	}



