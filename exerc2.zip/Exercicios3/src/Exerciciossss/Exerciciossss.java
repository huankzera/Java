package Exerciciossss;

import java.util.Scanner;





class Pessoa {
    private String cpf;
    private String nome;
    private char sexo;
    private int idade;

    public void setCPF(String cpf) {
        this.cpf = cpf;
    }

    public String getCPF() {
        return cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public char getSexo() {
        return sexo;
    }

    public String imprimir() {
        return "Nome: " + nome + "\nCPF: " + cpf + "\nSexo: " + sexo + "\nIdade: " + idade;
    }
}

public class Exerciciossss {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Pessoa pessoa = new Pessoa();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1 - Criar pessoa");
            System.out.println("2 - Mostrar pessoa");
            System.out.println("3 - Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Digite o CPF: ");
                    String cpf = scanner.next();
                    pessoa.setCPF(cpf);

                    System.out.print("Digite o nome: ");
                    String nome = scanner.next();
                    pessoa.setNome(nome);

                    System.out.print("Digite o sexo (M/F): ");
                    char sexo = scanner.next().charAt(0);
                    pessoa.setSexo(sexo);

                    System.out.print("Digite a idade: ");
                    int idade = scanner.nextInt();
                    pessoa.setIdade(idade);

                    System.out.println("Pessoa criada com sucesso!");
                    break;

                case 2:
                    System.out.println("\nDados da pessoa:\n" + pessoa.imprimir());
                    break;

                case 3:
                    System.out.println("Saindo...");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Opção inválida. Escolha uma opção válida.");
            }

            System.out.println(); 
        }
    }
}
    

