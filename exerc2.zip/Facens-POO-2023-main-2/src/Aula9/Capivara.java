package Aula9;

public class Capivara extends Animal{

    public Capivara(String nome, int idade) {
        super(nome, idade);
    }
    
}
