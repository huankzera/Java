package entities;

public class Depertament {

	private String name;
	
	public Depertament() {
	}

	public Depertament(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}