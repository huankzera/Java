package application;

import java.util.Scanner;

public class eleicao {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("Insira seu nome: ");
		String name = scan.nextLine();
		
		
		System.out.println("Insira sua data de nascimento: ");
		int dia = scan.nextInt();
		int mes = scan.nextInt();
		int ano = scan.nextInt();
		
		int x = 2023 - ano;
		
		if (x < 16) {
			System.out.println("Nao vota!");
			
		} else if (x>= 16 && x <=17 || x > 70){
			System.out.println("Voto Opcional");
			
		} else {
			System.out.println("Voto obrigatorio");
		}
		
		int y = ano + x;
		
		for (int i =x; i < 16; i++) {
			System.out.println("Voce nao podera votar em: "+y);
			           y++;
		}

	}

}
