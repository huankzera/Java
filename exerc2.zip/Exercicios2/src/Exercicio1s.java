
public class Exercicio1s {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3},
                          {4, 5, 6},
                          {7, 8, 9},
                          {10, 11, 12}};

        
        int linhas = matriz.length;
        int colunas = matriz[0].length;

        
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
