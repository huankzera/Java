
import java.util.Scanner;

public class Exercicio6s {
    public static void main(String[] args) {
        int[][] matriz = new int[3][5];

        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite os elementos da matriz:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }

        
        int[][] matrizModificada = new int[3][5];

        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                if (matriz[i][j] < 0) {
                    matrizModificada[i][j] = 0;
                } else {
                    matrizModificada[i][j] = matriz[i][j];
                }
            }
        }

        
        System.out.println("Matriz Original:");
        exibirMatriz(matriz);

        
        System.out.println("\nMatriz Modificada:");
        exibirMatriz(matrizModificada);

        scanner.close();
    }

    
    public static void exibirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
