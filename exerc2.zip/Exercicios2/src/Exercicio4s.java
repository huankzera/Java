
public class Exercicio4s {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3},
                          {4, 5, 6},
                          {7, 8, 9}};

        int[][] matrizDobro = new int[3][3];

        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrizDobro[i][j] = matriz[i][j] * 2;
            }
        }

        
        System.out.println("Matriz Original:");
        exibirMatriz(matriz);

        
        System.out.println("\nMatriz Dobro:");
        exibirMatriz(matrizDobro);
    }

    
    public static void exibirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
