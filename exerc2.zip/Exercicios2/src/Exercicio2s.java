
public class Exercicio2s {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3, 4},
                          {5, 6, 7, 8},
                          {9, 10, 11, 12}};

        
        int linhas = matriz.length;
        int colunas = matriz[0].length;

        
        int soma = 0;
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                soma += matriz[i][j];
            }
        }

        
        System.out.println("A soma dos elementos da matriz é: " + soma);
    }
}
