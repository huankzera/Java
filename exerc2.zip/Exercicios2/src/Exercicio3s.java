
public class Exercicio3s {
    public static void main(String[] args) {
        int[][] matriz = {{10, 5, 3},
                          {2, 8, 12},
                          {7, 6, 4},
                          {1, 9, 11},
                          {15, 14, 13}};

        
        int linhas = matriz.length;
        int colunas = matriz[0].length;

        int maiorElemento = matriz[0][0];
        int linhaMaior = 0;
        int colunaMaior = 0;

        
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                if (matriz[i][j] > maiorElemento) {
                    maiorElemento = matriz[i][j];
                    linhaMaior = i;
                    colunaMaior = j;
                }
            }
        }

        
        System.out.println("O maior elemento da matriz é: " + maiorElemento);
        System.out.println("Sua posição na matriz é: linha " + (linhaMaior + 1) + ", coluna " + (colunaMaior + 1));
    }
}
