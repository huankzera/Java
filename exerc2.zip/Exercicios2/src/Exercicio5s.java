import java.util.Scanner;

public class Exercicio5s {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3, 4},
                          {5, 6, 7, 8},
                          {9, 10, 11, 12}};

        
        int linhas = matriz.length;
        int colunas = matriz[0].length;

        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o número da linha (1 a " + linhas + "): ");
        int linhaEscolhida = scanner.nextInt();

        
        if (linhaEscolhida < 1 || linhaEscolhida > linhas) {
            System.out.println("Número de linha inválido!");
        } else {
            
            int soma = 0;
            for (int j = 0; j < colunas; j++) {
                soma += matriz[linhaEscolhida - 1][j];
            }
            double media = (double) soma / colunas;

            
            System.out.println("A média dos elementos da linha " + linhaEscolhida + " é: " + media);
        }

        scanner.close();
    }
}

